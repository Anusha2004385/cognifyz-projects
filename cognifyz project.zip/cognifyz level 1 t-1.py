def reverse_string(s):
    return s[::-1]
input_str = "hello"
reversed_str = reverse_string(input_str)
print(reversed_str)  