import re

def is_valid_email(email):
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(pattern, email) is not None

emails = [
    "dontalaanusha0@gmail.com",
    "dontalamukesh@gmail.com",
    "dontalaanusha0@gmail.com",
    "anusha.com",
    "dontalaanusha.com"
]

for email in emails:
    print(f"{email} -> {'Valid' if is_valid_email(email) else 'invalid'}")
