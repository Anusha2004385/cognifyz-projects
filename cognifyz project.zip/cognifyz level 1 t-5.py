def is_palindrome(s):
    s = s.replace(" ", "").lower()
    return s == s[::-1]
words = ["madam", "racecar", "hello", "Was it a car or a cat I saw"]
for word in words:
    result = is_palindrome(word)
    print(f"'{word}' -> {'Palindrome' if result else 'Not a palindrome'}")
