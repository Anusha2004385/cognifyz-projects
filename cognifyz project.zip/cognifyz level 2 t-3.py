import re

def check_password_strength(password):
    
    score = 0
    feedback = []

    
    if len(password) >= 12:
        score += 2
    elif len(password) >= 8:
        score += 1
    else:
        feedback.append("Password should be at least 8 characters long.")

    # Uppercase
    if re.search(r"[A-Z]", password):
        score += 1
    else:
        feedback.append("Password should include at least one uppercase letter.")

    # Lowercase
    if re.search(r"[a-z]", password):
        score += 1
    else:
        feedback.append("Password should include at least one lowercase letter.")

    # Digit
    if re.search(r"\d", password):
        score += 1
    else:
        feedback.append("Password should include at least one digit.")

    # Special character (any non-alphanumeric except spaces)
    if re.search(r"[^\w\s]", password):
        score += 1
    else:
        feedback.append("Password should include at least one special character.")

    # Cap score
    score = min(score, 6)

    # Strength levels
    if score >= 6:
        strength = "Strong  (Hard to crack)"
    elif score >= 4:
        strength = "Medium  (Could be stronger)"
    else:
        strength = "Weak (Very easy to guess)"

    result = f"Password Strength: {strength}"
    if feedback:
        result += "\nRecommendations:\n" + "\n".join(feedback)

    return result

if __name__ == "__main__":
    user_password = input("Enter your password: ")
    print(check_password_strength(user_password))
