def generate_fibonacci_sequence():
    
    while True:
        try:
            num_terms = int(input("Enter the number of terms for the Fibonacci sequence: "))
            if num_terms < 0:
                print("Please enter a non-negative integer.")
            else:
                break
        except ValueError:
            print("Invalid input. Please enter an integer.")

    # Generate Fibonacci sequence
    if num_terms == 0:
        fib_sequence = []
        print("The Fibonacci sequence with 0 terms is empty.")
    elif num_terms == 1:
        fib_sequence = [0]
        print("Fibonacci sequence:", *fib_sequence)
    else:
        fib_sequence = [0, 1]
        for _ in range(2, num_terms):
            fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
        print("Fibonacci sequence:", *fib_sequence)

    return fib_sequence

# Call the function
if __name__ == "__main__":
    generate_fibonacci_sequence()
