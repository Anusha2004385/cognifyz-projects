import re
from collections import Counter

def count_word_occurrences(filepath):
    
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            text = file.read().lower()
            words = re.findall(r'\b\w+\b', text)
            word_counts = Counter(words)
    except FileNotFoundError:
        print(f"Error: The file '{filepath}' was not found.")
        return {}
    except Exception as e:
        print(f"An error occurred: {e}")
        return {}

    # Sort by frequency (desc), then alphabetically
    sorted_word_counts = dict(sorted(word_counts.items(), key=lambda x: (-x[1], x[0])))
    return sorted_word_counts

if __name__ == "__main__":
    file_name = input("Enter the path to the text file: ")
    occurrences = count_word_occurrences(file_name)

    if occurrences:
        print("\nWord Occurrences (Sorted by Frequency):")
        for word, count in occurrences.items():
            print(f"{word}: {count}")
